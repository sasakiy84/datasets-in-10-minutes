Copyright (code): Linux source and notices / 2026-10-18

この添付は、スライドに引用したLinuxコードの原ファイル、著作権・ライセンス・免責表示とGPL version2の本文を保存する。PPTX/PDFと一緒に配布する。

Linux照合版: v6.0
commit: 4fe89d07dcc2804c8b562f6c7896a45643d34b2f
元ファイルの著作者: 各ファイル内の表示に従う（全表示を変更せず保持）。

収録ソースのコード内容は変更していない。プレゼンテーション用の連続範囲の選択とタブの4空白展開は2026-10-18、sasakiy84による。表示範囲と完全な参照の出所はattribution-index.jsonに対応する。

本添付のLinuxソースについて、各元ファイルが認めるGPL version2の適用選択肢を使用する。or-later/二重ライセンス等の元の表記を取り除かず保存している。GPL本文のNO WARRANTYを含む免責も参照する。これは実行可能なカーネル一式やモデル出力を新規生成するソフトウェアの配布ではなく、引用元13ファイルと権利記録の保存である。

HELMの採取コミットは不明。ここにあるLinux6.0は13参照全文の一致を確認した照合版であり、採取元の版を証明しない。

GPL-2.0.txt: Linux treeのLICENSES/preferred/GPL-2.0の未改変コピー（識別子案内と全文）。
COPYING: Linux全体の表示。
license-rules.rst: 個別ライセンスとSPDXの説明。
linux/: 元の13ソースファイル（著作権・免責・その他の表示も全文保存）。
